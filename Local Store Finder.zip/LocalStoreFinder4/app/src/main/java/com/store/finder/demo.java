package com.store.finder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class demo extends AppCompatActivity {

    String LoggedMobile,LoggedState,LoggedDist,LoggedSType;
    Owner owner;
    ListView listView;
    DatabaseReference databaseReference, logDatabase,data;
    FirebaseDatabase database;
   // Button makeCall, requestCall, sendMessage, sendMail;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);

        LoggedMobile = getIntent().getStringExtra("LoggedID");
        LoggedState = getIntent().getStringExtra("LoggedST");
        LoggedDist = getIntent().getStringExtra("LoggedDST");
        LoggedSType = getIntent().getStringExtra("LoggedSType");

        listView = findViewById(R.id.listm);

        list = new ArrayList<>();
        //img = (ImageView) findR.drawable.logo;
        adapter = new ArrayAdapter<String>(this, R.layout.activity_owner_info, R.id.ownerinfo, list);
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference().child("RegisteredShop");
        logDatabase = databaseReference.child(LoggedState).child(LoggedDist).child(LoggedSType);
        data = logDatabase.child(LoggedMobile);

        Toast.makeText(demo.this,data.toString(),Toast.LENGTH_SHORT).show();

        data.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                try {
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        owner = ds.getValue(Owner.class);
                        String call = owner.getMobile_Number();
                        Toast.makeText(demo.this, call, Toast.LENGTH_SHORT).show();
                        list.add("  Owner Name  : " + owner.getOwner_Name() +
                                '\n' + "  Shop Name    : " + owner.getShop_Name() +
                                '\n' + "  Shop Address: " + owner.getAddress() ); //+img.getDrawable());//(R.drawable.logo));
                        // Toast.makeText(ShopList.this, owner.getMobile_Number().toString(), Toast.LENGTH_SHORT).show();
                    }
                    listView.setAdapter(adapter);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}