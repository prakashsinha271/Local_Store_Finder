package com.store.finder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustRating extends AppCompatActivity {

    private RatingBar rBar,ratesbar;
    private TextView tView,tcust;
    private Button btn;
    DatabaseReference database, childRef;
    String LoggedMobile, LoggedState, LoggedDist, LoggedSType,Shopdetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_rating);

        LoggedMobile = getIntent().getStringExtra("LoggedID");
        LoggedState = getIntent().getStringExtra("LoggedST");
        LoggedDist = getIntent().getStringExtra("LoggedDST");
        Shopdetails = getIntent().getStringExtra("OwnerMobile");
        //LoggedMsg = getIntent().getStringExtra("LoggedMSG");
        LoggedSType = getIntent().getStringExtra("LoggedSType");

        database = FirebaseDatabase.getInstance().getReference().child("RegisteredShop");
        childRef = database.child(LoggedState).child(LoggedDist).child(LoggedSType).child(LoggedMobile);

//        Toast.makeText(getApplicationContext(), LoggedMobile, Toast.LENGTH_LONG).show();

        rBar = findViewById(R.id.RatingBar);
        ratesbar = findViewById(R.id.ratingBar);
        tView = findViewById(R.id.textview1);
        tcust = findViewById(R.id.txtcustcount);
        btn = findViewById(R.id.btnGet);

        childRef.child("Rate").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final Double ratbars = dataSnapshot.getValue(Double.class);
                //tView.setText(String.valueOf(acc));
                ratesbar.setRating(Float.parseFloat(String.valueOf(ratbars)));
               // Toast.makeText(CustRating.this,String.valueOf(ratbars),Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        childRef.child("Rating").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final Double acc = dataSnapshot.getValue(Double.class);
                tView.setText(String.valueOf(acc));
                //Toast.makeText(CustRating.this,String.valueOf(acc),Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        childRef.child("Total_Customer_Rate").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final Integer tcr = dataSnapshot.getValue(Integer.class);
                tcust.setText(String.valueOf(tcr));
                //Toast.makeText(CustRating.this,String.valueOf(acc),Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager manager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activenetwork = manager.getActiveNetworkInfo();
                if(null != activenetwork) {
                    btn.setEnabled(false);
                    float getratings = rBar.getRating();
                    //Toast.makeText(CustRating.this,tView.getText(),Toast.LENGTH_SHORT).show();
                    Double totalRate =  (Double.parseDouble(tView.getText().toString()) + getratings);
                    int totalcust = Integer.parseInt(tcust.getText().toString()) + 1;
                    //Toast.makeText(CustRating.this, (int) totalRate,Toast.LENGTH_SHORT).show();
                    childRef.child("Rating").setValue(totalRate);
                    childRef.child("Total_Customer_Rate").setValue(totalcust);
                    Double rates = (totalRate/(totalcust*5))*5;
                    childRef.child("Rate").setValue(rates);
                    back();
                } else   {
                    AlertDialog.Builder alert = new AlertDialog.Builder(CustRating.this);
                    alert.setTitle("Hii,");
                    alert.setMessage("Please Enable Network !!");
                    alert.setPositiveButton("Ok",null);
                    alert.show();
                }

            }
        });

    }

    private void back() {
        Intent intent = new Intent(CustRating.this,ListviewCallChat.class);
        intent.putExtra("LoggedSType", LoggedSType);
        intent.putExtra("LoggedST", LoggedState);
        intent.putExtra("LoggedDST", LoggedDist);
        intent.putExtra("LoggedID", Shopdetails);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
       back();
    }

}

        /*
        childRef.child("Rating").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String previousRate = snapshot.getValue(String.class);
                //Toast.makeText(CustRating.this,previousRate, Toast.LENGTH_LONG).show();

                if(previousRate != null) {
                            //Toast.makeText(getApplicationContext(), previousRate, Toast.LENGTH_LONG).show();
                            tView.setText(previousRate);
                    //float getratings = rBar.getRating();
                    //int totalRate = (int) (Integer.parseInt(previousRate) + getratings);
                    //childRef.child("Rating").setValue(String.valueOf(totalRate));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), tView.getText().toString(), Toast.LENGTH_LONG).show();
                //int noofstars = rBar.getNumStars();
                //final float getrating = rBar.getRating();
                // tView.setText("Rating: "+getrating+"/"+noofstars);
                // int totalRate = (int) (Integer.parseInt(String.valueOf(tView)) + getrating);
                // childRef.child("Rating").setValue(String.valueOf(totalRate));

                //int rate = tView.getInputType();
                //Toast.makeText(CustRating.this,tView.getText().toString(), Toast.LENGTH_LONG).show();

                /*childRef.child("Rating").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String previousScore = dataSnapshot.getValue(String.class);
                        float getrating = rBar.getRating();
                        assert previousScore != null;
                        float finalScore = Float.parseFloat(previousScore) + getrating;

                         // float finalScore = Integer.parseInt(String.valueOf(previousScore)); //+ getrating;
                         Toast.makeText(CustRating.this, String.valueOf(finalScore), Toast.LENGTH_LONG).show();
                         childRef.child("Rating").setValue(finalScore);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

    }
}

         */